import React from 'react'
import { counterAction } from '../store/counter-slice'
import { useSelector, useDispatch } from 'react-redux'

const Home = () => {
    //to get data
    // useSelector((state) => console.log("== Master Object ==\n",state));

    const value  = useSelector((state) => state.counter.count);
    const value1  = useSelector((state) => state.counter.name);
    // console.log("== value of count from store ==",value1);

    //For sending data to store use CAPITAL WORD TO when making DISPATCH its fixed word.
    const DISPATCH = useDispatch();


    return (
        <div>
            <h1>Home</h1>
            <h1>{value}</h1>
            <button onClick={() => DISPATCH(counterAction.increment()) }>increase</button> 
            <button onClick={() => DISPATCH(counterAction.decrement()) }>decrease</button>
            <button onClick={() => DISPATCH(counterAction.addTenNumber()) }>add 10 </button>
            <button onClick={() => DISPATCH(counterAction.addGivenNumber([1,2,3,4,5,6,7,8,9,])) }>
                add passed value 
            </button>
        </div>
    )
}

export default Home