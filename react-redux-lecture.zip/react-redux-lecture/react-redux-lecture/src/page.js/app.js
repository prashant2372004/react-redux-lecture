import React from 'react'
import Home from './home';
import ObjectConceptClear from '../conept-clear/object-concept';

const App = () => {
  return (
    <div>
      <Home />
      {/* <ObjectConceptClear/> */}
    </div>
  )
}

export default App