import  {configureStore , createSlice} from "@reduxjs/toolkit"
import { counterSlice } from "./counter-slice"


// store declare only one time for one project. slices can be many
export const mainStore  = configureStore({
    reducer:{
        counter:counterSlice.reducer
    }
})



















//========= For Large Project Slice created in seperate  and file then imported ========

// export const mainStore  = configureStore({
//     reducer:{
//         counter:counterSlice.reducer,
//         productPage: productSlice.reducer,
//         userPage : userSlice.reducer,
//         cartPage: createSlice.reducer,
//         // slice can be made in seprate file and then imported in store 
//     }
// })


