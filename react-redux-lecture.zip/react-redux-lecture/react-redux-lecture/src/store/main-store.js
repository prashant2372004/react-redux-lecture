import {configureStore } from "@reduxjs/toolkit";
import { productSlice } from "./product-slice";

export const mainStore  = configureStore({
    reducer:{
        product: productSlice.reducer
    }
    
})