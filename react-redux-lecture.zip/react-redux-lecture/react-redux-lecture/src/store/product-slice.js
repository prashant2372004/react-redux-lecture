import { createSlice} from '@reduxjs/toolkit';



const intialState ={
    products:["aaaaaa", "ggggggg"],
    productList :{},
    cartProduct:"ssssss"
}


export const productSlice = createSlice({
    name:"product",
    initialState:intialState,
    reducers:{
        
        addProductList: (state, action)=>{
            console.log("=== addProductList===", state, action);
            
        }
    }
})


export const productActions = productSlice.actions