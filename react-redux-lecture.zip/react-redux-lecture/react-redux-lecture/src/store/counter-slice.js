// // mainStore

// import  {configureStore , createSlice} from "@reduxjs/toolkit"
// import { counterSlice } from "./counter-slice"


// // store declare only one time for one project. slices can be many
// export const mainStore  = configureStore({
//     reducer:{
//         counter:counterSlice.reducer
//     }
// })





















import  {configureStore , createSlice} from "@reduxjs/toolkit"

const initialState ={
    count:0,
    name:"MAyur",
    obj:{},
    arr:[]
}

export const counterSlice = createSlice({
    name :"counter",
    initialState: initialState,
    reducers:{
        increment:(state )=>{
            console.log("== increment called ==", state.count);
            state.count = state.count + 1;
        },
        decrement:(state )=>{
            console.log("== decrement called ==");
            state.count = state.count - 1;
        },
        addTenNumber:(state )=>{
            console.log("== addTenNumber called ==");
            state.count = state.count + 10 ;
        },
        addGivenNumber: (state, action )=>{
            console.log("== addGivenNumber called ==",action.payload);
            state.count  = state.count + action.payload;
        },
    }
});

export const counterAction  = counterSlice.actions;


// //page
// import React from 'react'
// import { counterAction } from '../store/counter-slice'
// import { useSelector, useDispatch } from 'react-redux'
// import { mainStore } from "./mainStore";

// const Home = () => {
//     //to get data
//     // useSelector((state) => console.log("== Master Object ==\n",state));

//     const value  = useSelector((state) => state.counter.count);
//     const value1  = useSelector((state) => state.counter.name);
//     // console.log("== value of count from store ==",value1);

//     //For sending data to store use CAPITAL WORD TO when making DISPATCH its fixed word.
//     const DISPATCH = useDispatch();
//     return (
//         <div>
//             <h1>Home</h1>
//             <h1>{value}</h1>
//             <button onClick={() => DISPATCH(counterAction.increment()) }>increase</button> 
//             <button onClick={() => DISPATCH(counterAction.decrement()) }>decrease</button>
//             <button onClick={() => DISPATCH(counterAction.addTenNumber()) }>add 10 </button>
//             <button onClick={() => DISPATCH(counterAction.addGivenNumber([1,2,3,4,5,6,7,8,9,])) }>
//                 add passed value 
//             </button>
//         </div>
//     )
// }

// export default Home