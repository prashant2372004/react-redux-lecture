import React from 'react'

const ObjectConceptClear = () => {

//Nested Objects  

    const MasterObject = {
        name:"",
        email:"",
        objectInsideObject: { userName :"mayur", email:"mayur.malaviya@yopmail.com"},
        ArrowFunctionSavedObject:  ()=>{ console.log("== hey i'm function, My Home is Mater Object.")},
        simpleFunctionSavedInObject : function sum(x, y) {return x + y }
    }

    return (
        <div>
            <h1> Important object Concept </h1>
            <h4> get values from MasterObject >> objectInsideObject >> userName :- { MasterObject.objectInsideObject.userName}</h4>
            <button onClick={() => MasterObject.ArrowFunctionSavedObject()}>call saved function of Master Object</button>
        </div>
    )
}

export default ObjectConceptClear