import React from "react";
import Home from "./home";


const App =()=>{
    return(
        <div>
            <h1>app</h1>
            <Home/>
        </div>
    )
}

export default App;