import React from 'react'
import {useSelector, useDispatch } from 'react-redux'
import {productActions} from '../store/product-slice'

const Home = () => {
    
    useSelector((state)=>{console.log(">>>>>>>>>>>>>>>>", state.product.products);})
    const DISPATCH  = useDispatch()

    // DISPATCH(productActions.addProducts([10,20, 30,40]));
  return (
    <div>
        <button onClick={()=> DISPATCH(productActions.addProducts([10,20, 30,40]))}>click</button>
    </div>
  )
}

export default Home